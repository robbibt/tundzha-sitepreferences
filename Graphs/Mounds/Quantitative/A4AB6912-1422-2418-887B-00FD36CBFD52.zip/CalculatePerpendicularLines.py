# ---------------------------------------------------------------------------
# Create Perpendicular Lines
# August 16, 2008
#   Gerry Gabrisch, gerry@gabrisch.us  (I am finishing graduate school, I need a job!)
#Created for ArcGIS9.2, 9.1 users, please check the knowledgebase link below about error messages before writing.
# http://support.esri.com/index.cfm?fa=knowledgebase.techarticles.articleShow&d=31900
# ---------------------------------------------------------------------------
try:
    # Import system modules
    import sys, string, os, arcgisscripting
    
    # Create the Geoprocessor object
    gp = arcgisscripting.create()
    
    # Local variables...
    
    # inputlines = r"C:\Temp\lidar_flowlines_Clip.shp"
    inputlines = sys.argv[1]
    
    distance = 30.0

    # textfile = r"C:\Temp\output.txt"
    textfile = sys.argv[3]
    
    print "please wait, working on file " + inputlines
    print "evaluation distance = " + str(distance)
    print "text file location = " + textfile
    
    #Create a text file and write polylines to the first line.
    f = open(textfile,'a')
    thestring = "polyline\n"
    f.writelines(thestring)
    f.close()   
    
    # Create search cursor
    rows = gp.SearchCursor(inputlines)
    row = rows.Next()
   
    counter = 0
    #start the row iteration
    while row:
    # Create the geometry object
        feat = row.Shape
        #get coordinate values as lists
        firstpoint = feat.FirstPoint
        lastpoint = feat.LastPoint
        midpoint = feat.Centroid
        #split the lists by the blank space between the coordinate pairs
        firstpoint = firstpoint.split(" ")
        lastpoint = lastpoint.split(" ")
        midpoint = midpoint.split(" ")
        #get the x and y values as array positions 0 and 1, and convert them to floating point numbers from the native string literals
        startx = float(firstpoint[0])
        starty = float(firstpoint[1])
        endx = float(lastpoint[0])
        endy = float(lastpoint[1])
        midx = float(midpoint[0])
        midy = float(midpoint[1])
        
        
        #if the line is horizontal or vertical the slope and negreciprocal will fail so do this instead.
        if starty==endy or startx==endx:
            if starty == endy:
                y1 = midy + distance
                y2 = midy - distance
                x1 = midx
                x2 = midx
    
            if startx == endx:
                y1 = midy
                y2 = midy 
                x1 = midx + distance
                x2 = midx - distance
        
        
        else:
        
            #get the slope of the line
            m = ((starty - endy)/(startx - endx))
            
            #get the negative reciprocal, 
            negativereciprocal = -1*((startx - endx)/(starty - endy))
            
            if m > 0:
                #increase x values, find y
                if m >= 1:
                    y1 = negativereciprocal*(distance)+ midy
                    y2 = negativereciprocal*(-distance) + midy
                    x1 = midx + distance
                    x2 = midx - distance
                #increase y find x
                if m < 1:
                    y1 = midy + distance
                    y2 = midy - distance
                    x1 = (distance/negativereciprocal) + midx
                    x2 = (-distance/negativereciprocal)+ midx
                    
            if m < 0:
                #add to x find y
                if m >= -1:
                #add to y find x
                    y1 = midy + distance
                    y2 = midy - distance
                    x1 = (distance/negativereciprocal) + midx
                    x2 = (-distance/negativereciprocal)+ midx  
                
                if m < -1:
                    y1 = negativereciprocal*(distance)+ midy
                    y2 = negativereciprocal*(-distance) + midy
                    x1 = midx + distance
                    x2 = midx - distance

            
        f = open(textfile,'a')
        thestring = str(counter) + " 0\n" + "0 "+ str(x1)+" "+str(y1) + "\n" + "1 " + str(x2) + " " + str(y2) +"\n"
        f.writelines(thestring)
        f.close()   
        del x1
        del x2
        del y1
        del y2
        
        counter = counter + 1
        
        row = rows.Next()
 
    del row
    del rows
    f = open(textfile,'a')
    thestring = "END"
    f.writelines(thestring)
    f.close()   
    
except:
    print "Failed"
    gp.AddMessage(gp.GetMessages(2))
    print gp.GetMessages(2)
    del gp
    
    
del gp

#Ends the script        
#stopme = raw_input ("your script has finished, press enter to end")











    
