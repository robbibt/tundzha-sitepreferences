import arcgisscripting
import os

def point2line():
    gp = arcgisscripting.create(9.3)
    gp.OverWriteOutput = 1

    # Input point FC
    inPts = gp.GetParameterAsText(0)
    # Output polyline FC
    outLine = gp.GetParameterAsText(1)
    # LineID Field
    IDField = gp.GetParameterAsText(2)
    # Sort Field
    sortField = gp.GetParameterAsText(3)
    if sortField == "#":
        sortField = ""

    if sortField == "":
        cursorSort = IDField
    else:
        cursorSort = IDField + ";" + sortField

    createLinesFromPoints(gp, inPts, outLine, IDField, cursorSort) 

def createLinesFromPoints(gp, inPts, outLine, IDField, cursorSort):
    try:
        # Assign empty values to cursor and row objects
        iCur, sRow, sCur, feat = None, None, None, None

        shapeName = gp.Describe(inPts).ShapeFieldName

        # Create the output feature class
        #
        outPath, outFC = os.path.split(outLine)
        gp.CreateFeatureClass(outPath, outFC, "Polyline", inPts, "", "", inPts)

        # Open an insert cursor for the new feature class
        #
        iCur = gp.InsertCursor(outLine)
        sCur = gp.SearchCursor(inPts, "", None, cursorSort, cursorSort)

        sRow = sCur.Next()

        # Create an array and point object needed to create features
        #
        lineArray = gp.CreateObject("Array")
        pt = gp.CreateObject("Point")

        # Initialize a variable for keeping track of a feature's ID.
        #
        ID = -1
        while sRow:
            pt = sRow.GetValue(shapeName).GetPart(0)            
            currentValue = sRow.GetValue(IDField)

            if ID == -1:
                ID = currentValue

            if ID <> currentValue:
                if lineArray.count > 1:
                    feat = iCur.NewRow()
                    if ID: #in case the value is None/Null
                        feat.SetValue(IDField, ID)
                    feat.SetValue(shapeName, lineArray)
                    iCur.InsertRow(feat)
                else:
                    gp.AddWarning("Not enough points to create a line for %s: %s" % (IDField, str(ID)))
                lineArray.RemoveAll()

            lineArray.Add(pt)
            ID = currentValue
            sRow = sCur.Next()

        # Add the last feature
        #
        if lineArray.count > 1:
            feat = iCur.NewRow()
            if ID: #in case the value is None/Null
                feat.SetValue(IDField, currentValue)
            feat.SetValue(shapeName, lineArray)
            iCur.InsertRow(feat)
        else:
            gp.AddWarning("Not enough points to create a line for %s: %s" % (IDField, str(ID)))
        lineArray.RemoveAll()

    except Exception, err:
        print err.message
        gp.AddError(err.message)

    finally:
        if iCur:
            del iCur
        if sRow:
            del sRow
        if sCur:
            del sCur
        if feat:
            del feat

if __name__ == '__main__':
    point2line()


